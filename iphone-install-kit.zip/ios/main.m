#import <UIKit/UIKit.h>
#import <WebKit/WebKit.h>

@interface TaxSchemeHandler : NSObject <WKURLSchemeHandler>
@property(nonatomic, copy) NSString *root;
@end

@implementation TaxSchemeHandler
- (void)webView:(WKWebView *)webView startURLSchemeTask:(id<WKURLSchemeTask>)task {
    NSURL *url = task.request.URL;
    NSString *path = url.path.length ? url.path : @"/index.html";
    NSString *relative = [path hasPrefix:@"/"] ? [path substringFromIndex:1] : path;
    NSString *file = [self.root stringByAppendingPathComponent:relative];
    NSString *standard = file.stringByStandardizingPath;
    if (![standard hasPrefix:[self.root.stringByStandardizingPath stringByAppendingString:@"/"]]) {
        [task didFailWithError:[NSError errorWithDomain:@"TaxDemo" code:403 userInfo:nil]]; return;
    }
    NSData *data = [NSData dataWithContentsOfFile:standard];
    if (!data) { [task didFailWithError:[NSError errorWithDomain:@"TaxDemo" code:404 userInfo:nil]]; return; }
    NSDictionary *mime = @{@"html":@"text/html", @"js":@"application/javascript", @"css":@"text/css", @"json":@"application/json", @"png":@"image/png", @"jpg":@"image/jpeg", @"jpeg":@"image/jpeg", @"svg":@"image/svg+xml", @"woff":@"font/woff", @"ttf":@"font/ttf"};
    NSString *type = mime[standard.pathExtension.lowercaseString] ?: @"application/octet-stream";
    NSURLResponse *response = [[NSURLResponse alloc] initWithURL:url MIMEType:type expectedContentLength:data.length textEncodingName:@"utf-8"];
    [task didReceiveResponse:response]; [task didReceiveData:data]; [task didFinish];
}
- (void)webView:(WKWebView *)webView stopURLSchemeTask:(id<WKURLSchemeTask>)task {}
@end

@interface TaxAppDelegate : UIResponder <UIApplicationDelegate>
@property(nonatomic, strong) UIWindow *window;
@end
@implementation TaxAppDelegate
- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)options {
    self.window = [[UIWindow alloc] initWithFrame:UIScreen.mainScreen.bounds];
    WKWebViewConfiguration *config = [WKWebViewConfiguration new];
    TaxSchemeHandler *handler = [TaxSchemeHandler new];
    handler.root = [NSBundle.mainBundle pathForResource:@"Web" ofType:nil];
    [config setURLSchemeHandler:handler forURLScheme:@"taxdemo"];
    WKWebView *web = [[WKWebView alloc] initWithFrame:CGRectZero configuration:config];
    web.translatesAutoresizingMaskIntoConstraints = NO;
    [web loadRequest:[NSURLRequest requestWithURL:[NSURL URLWithString:@"taxdemo://app/index.html"]]];
    self.window.rootViewController = [UIViewController new];
    [self.window.rootViewController.view addSubview:web]; self.window.rootViewController.view.backgroundColor = UIColor.whiteColor;
    UILayoutGuide *safe = self.window.rootViewController.view.safeAreaLayoutGuide;
    [NSLayoutConstraint activateConstraints:@[
      [web.topAnchor constraintEqualToAnchor:safe.topAnchor],
      [web.bottomAnchor constraintEqualToAnchor:safe.bottomAnchor],
      [web.leadingAnchor constraintEqualToAnchor:safe.leadingAnchor],
      [web.trailingAnchor constraintEqualToAnchor:safe.trailingAnchor]
    ]];
    [self.window makeKeyAndVisible]; return YES;
}
@end
int main(int argc, char *argv[]) { @autoreleasepool { return UIApplicationMain(argc, argv, nil, NSStringFromClass(TaxAppDelegate.class)); } }
