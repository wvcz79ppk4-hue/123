#!/bin/bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"; OUT="$ROOT/build/Payload/TaxDemo.app"
mkdir -p "$OUT"
xcrun --sdk iphoneos clang -isysroot "$(xcrun --sdk iphoneos --show-sdk-path)" -target arm64-apple-ios15.0 -fobjc-arc -framework UIKit -framework WebKit -framework Foundation "$ROOT/ios/main.m" -o "$OUT/TaxDemo"
cp "$ROOT/Info.plist" "$OUT/Info.plist"; cp -R "$ROOT/Web" "$OUT/Web"
codesign --remove-signature "$OUT/TaxDemo" 2>/dev/null || true
mkdir -p "$ROOT/dist"; (cd "$ROOT/build" && zip -qr "$ROOT/dist/TaxDemo-unsigned.ipa" Payload)
echo "Created unsigned IPA: $ROOT/dist/TaxDemo-unsigned.ipa"
