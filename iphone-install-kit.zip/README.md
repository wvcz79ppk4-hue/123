# 个税演示 iPhone 安装包准备

这是一个使用系统 WKWebView 加载已构建 H5 的原生 iOS 容器。Windows 不能编译 iOS Mach-O；仓库根目录的 GitHub Actions 工作流会在 macOS runner 上生成 `TaxDemo-unsigned.ipa`，随后需要使用用户自己的 Apple ID / AltStore 签名安装。此流程不包含付费开发者服务，也不会伪造签名。

工作流完成后，从 Actions artifact 下载 IPA，再在 AltStore/AltServer 中用自己的 Apple ID 安装。免费个人签名通常需要周期性续签，应用数据保存在手机本地；项目原有 API 仍需网络可用。

本机只能验证工程结构，不能声称 IPA 已生成或已在 iPhone 上安装。
